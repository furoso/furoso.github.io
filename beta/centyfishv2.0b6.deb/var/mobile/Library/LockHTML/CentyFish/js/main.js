function mainUpdate(type){
  updateDate();
  updateTime();
  if(type == "weather"){
    temperature = weather.temperature;
    condition = weather.condition;
    conditionCode = weather.conditionCode;
    high = weather.high;
    low = weather.low;
    rainchance = weather.chanceofrain;
    city = weather.address.city;
    sunset = weather.sunsetTimeFormatted;
    sunrise = weather.sunriseTimeFormatted;
    windspeed = weather.windSpeed;
    winddirection = weather.windDirection;
    humidity = weather.humidity;
    pressure = weather.pressure;
    var now = new Date();
    var sunrisestamp = new Date(now.getFullYear(), now.getMonth(), now.getDate(), sunrise.split(":")[0], sunrise.split(":")[1]);
    var sunsetstamp = new Date(now.getFullYear(), now.getMonth(), now.getDate(), sunset.split(":")[0], sunset.split(":")[1]);
    if(now > sunrisestamp && now <= sunsetstamp) {
      sunsetrise = sunset;
      sunsetriseicon = "33";
    } else {
      sunsetrise = sunrise;
      sunsetriseicon = "32";
    }
    
    setWeather(false);
  } else if(type == "battery") {
    percent = batteryPercent + "%";
  } else if(type == "alarm") {
    alarm = alarms[0].nextFireDateTimeParsed;
    if(alarm == "") {
      isalarm = false;
    } else {
      isalarm = true;
    }
  }
}

function init() {
  document.getElementById("weather").className = WeatherDefaultMode;
  weatherFired = false;
  alarmFired = false;
  batteryFired = false;

  if(Mode == "leftyfish") {
    document.body.style.textAlign = "left";
  } else if(Mode == "centyfish") {
    document.body.style.textAlign = "center";
  } else {
    document.body.style.textAlign = "right";
  }

  document.getElementById("weather").style.textShadow = "0 0 " + WeatherTextShadowBlur + " " + WeatherTextShadowColor;
  document.getElementById("weathericon").style.textShadow = "0 0 " + WeatherTextShadowBlur + " " + WeatherTextShadowColor;
  document.getElementById("time").style.textShadow = "0 0 " + TimeTextShadowBlur + " " + TimeTextShadowColor;
  document.getElementById("date").style.textShadow = "0 0 " + DateTextShadowBlur + " " + DateTextShadowColor;

  var icon = "26";
  document.getElementById("weathericon").innerHTML = "<img id='icon' src=icons/" + icon + ".png height='" + WeatherIconSize + "' />";

  setInterval("updateTime(); updateDate();", 1000);

  if(!ShowWeatherIcon) {
    document.getElementById("weathericon").innerHTML = "";
    document.getElementById("weathericon").style.right = "0";
    document.getElementById("weathericon").style.width = "0";
  }

  if(ShowWeather) {
    if(WeatherTextColorAuto) {
      autoColor("weather", WeatherTextColorAutoTheme);
      autoColor("weathericon", WeatherTextColorAutoTheme);
    } else {
      document.getElementById("weather").style.color = WeatherTextColor;
      document.getElementById("weathericon").style.color = WeatherTextColor;
    }
    document.getElementById("weather").style.fontSize = WeatherFontSize;
    document.getElementById("weather").style.fontWeight = WeatherFontWeight;
    document.getElementById("weathericon").style.fontSize = WeatherFontSize;
    document.getElementById("weathericon").style.fontWeight = WeatherFontWeight;
  } else {
    document.getElementById("weathercontainer").style.visibility = "hidden";
    ShowWeatherIcon = false;
  }

  if(ShowTime) {
    if(TimeTextColorAuto) {
      autoColor("time", TimeTextColorAutoTheme);
    } else {
      document.getElementById("time").style.color = TimeTextColor;
      document.getElementById("time").style.fill = TimeTextColor;
    }
    document.getElementById("time").style.fontSize = TimeFontSize;
    document.getElementById("time").style.fontWeight = TimeFontWeight;
  } else {
    document.getElementById("time").style.visibility = "hidden";
  }

  if(ShowDate) {
    if(DateTextColorAuto) {
      autoColor("date", DateTextColorAutoTheme);
    } else {
      document.getElementById("date").style.color = DateTextColor;
    }
    document.getElementById("date").style.fontSize = DateFontSize;
    document.getElementById("date").style.fontWeight = DateFontWeight;
  } else {
    document.getElementById("date").style.visibility = "hidden";
  }
}

function updateDate() {
  if(!batteryFired) {
    let now = new Date();
    var days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    var date = days[now.getDay()] + " " + String(now.getDate()).padStart(2, '0');
    document.getElementById("date").innerHTML = date;
  }
}

function updateTime() {
  if(!alarmFired) {
    let now = new Date();
    if(now.getMinutes() < 10) {
      var minutes = "0" + now.getMinutes();
    } else {
      var minutes = now.getMinutes();
    }
    if(TimeFormat == "12h") {
      var ampm = now.getHours() >= 12 ? 'pm' : 'am';
      var hours = now.getHours() % 12;
      var hours = hours ? hours : 12; // the hour '0' should be '12'
      if(TimeShowAmPm) {
        var time = hours + ":" + minutes + " " + ampm;
      } else {
        var time = hours + ":" + minutes;
      }
    } else {
      var hours = now.getHours();
      var time = hours + ":" + minutes;
    }
    document.getElementById("time").innerHTML = time;
  }
}

function autoColor(object, mode) {
  var img = document.createElement('img');
  img.setAttribute('src', '/var/mobile/Library/SpringBoard/LockBackgroundThumbnail.jpg');

  img.addEventListener('load', function() {
      var vibrant = new Vibrant(img);
      var swatches = vibrant.swatches();
      for (var swatch in swatches) {
        if (swatches.hasOwnProperty(swatch) && swatches[swatch]) {
          if(swatch == mode) {
            document.getElementById(object).style.color = swatches[swatch].getHex();
            document.getElementById(object).style.fill = swatches[swatch].getHex();
            console.log(swatch, swatches[swatch].getHex());
          } 
        }
      }
  });
}

function showBattery() {
  if(!batteryFired) {
    batteryFired = true;
    $("#date").fadeOut(500);
    setTimeout(function(){ 
      document.getElementById("date").innerHTML = percent; 
      $("#date").fadeIn(500); 
      setTimeout(function(){
        $("#date").fadeOut(500); 
        setTimeout(function(){
          batteryFired = false;
          updateDate();
          $("#date").fadeIn(500); 
        }, 500);
      }, 3000);
    }, 500);
  }
}
  
function showAlarm() {
  if(TapTime) {
    if(!alarmFired) {
      if(isalarm) {
        alarmFired = true;
        $("#time").fadeOut(500);
        setTimeout(function(){ 
          document.getElementById("time").innerHTML = "<div id='svgContainer'></div> " + alarm; 
          xhr = new XMLHttpRequest();
          xhr.open("GET","icons/alarm.svg",false);
          xhr.overrideMimeType("image/svg+xml");
          xhr.send("");
          document.getElementById("svgContainer").appendChild(xhr.responseXML.documentElement);

          document.getElementById("svgContainer").style.height = (parseInt(TimeFontSize.replace(/px/,""))*0.5)+"px";
          document.getElementById("svgContainer").style.width = (parseInt(TimeFontSize.replace(/px/,""))*0.5)+"px";
          $("#time").fadeIn(500); 
          setTimeout(function(){
            $("#time").fadeOut(500); 
            setTimeout(function(){
              alarmFired = false;
              updateTime();
              $("#time").fadeIn(500); 
            }, 500);
          }, 3000);
        }, 500);
      }
    }
  } else {
    changeWeather();
  }
}

function changeWeather() {
  if(document.getElementById("weather").className == "now") {
    document.getElementById("weather").className = "highlow";
  } else if(document.getElementById("weather").className == "highlow") {
    document.getElementById("weather").className = "sunsetrise";
  } else if(document.getElementById("weather").className == "sunsetrise") {
    document.getElementById("weather").className = "rainchance";
  } else if(document.getElementById("weather").className == "rainchance") {
    document.getElementById("weather").className = "humpress";
  } else if(document.getElementById("weather").className == "humpress") {
    document.getElementById("weather").className = "wind";
  } else if(document.getElementById("weather").className == "wind") {
    document.getElementById("weather").className = "address";
  } else if(document.getElementById("weather").className == "address") {
    document.getElementById("weather").className = "now";
  } 
  setWeather(true);
}

function setWeather(fade) {
  weatherMode = document.getElementById("weather").className;
  if(fade && !weatherFired) {
    weatherFired = true;
    $("#weathercontainer").fadeOut(500);
    setTimeout(function(){
      if(weatherMode == "now") {
        document.getElementById("weather").innerHTML = temperature + "° " + condition;
        if(ShowWeatherIcon && ShowWeather) {
          document.getElementById("weathericon").innerHTML = "<img src=icons/" + conditionCode + ".png height='" + WeatherIconSize + "' />";
        }
      } else if(weatherMode == "highlow") {
        document.getElementById("weather").innerHTML = high + "° / " + low + "°";
        if(ShowWeatherIcon && ShowWeather) {
          document.getElementById("weathericon").innerHTML = "<img src=icons/" + conditionCode + ".png height='" + WeatherIconSize + "' />";
        }
      } else if(weatherMode == "sunsetrise") {
        document.getElementById("weather").innerHTML = sunsetrise;
        if(ShowWeatherIcon && ShowWeather) {
          document.getElementById("weathericon").innerHTML = "<img src=icons/" + sunsetriseicon + ".png height='" + WeatherIconSize + "' />";
        }
      } else if(weatherMode == "rainchance") {
        document.getElementById("weather").innerHTML = rainchance + "%";
        if(ShowWeatherIcon && ShowWeather) {
          document.getElementById("weathericon").innerHTML = "<img src=icons/11.png height='" + WeatherIconSize + "' />";
        }
      } else if(weatherMode == "humpress") {
        document.getElementById("weather").innerHTML = "RH: " + humidity + "%&nbsp;&nbsp;" + pressure + "hPa";
        if(ShowWeatherIcon && ShowWeather) {
          document.getElementById("weathericon").innerHTML = "<img src=icons/" + conditionCode + ".png height='" + WeatherIconSize + "' />";
        }
      } else if(weatherMode == "wind") {
        document.getElementById("weather").innerHTML = windspeed + "km/h " + getCardinal(winddirection);
        if(ShowWeatherIcon && ShowWeather) {
          document.getElementById("weathericon").innerHTML = "<img src=icons/23.png height='" + WeatherIconSize + "' />";
        }
      } else if(weatherMode == "address") {
        document.getElementById("weather").innerHTML = temperature + "° " + city;
        if(ShowWeatherIcon && ShowWeather) {
          document.getElementById("weathericon").innerHTML = "<img src=icons/" + conditionCode + ".png height='" + WeatherIconSize + "' />";
        }
      }
      $("#weathercontainer").fadeIn(500); 
      setTimeout(function(){ weatherFired = false }, 501);
    }, 500);
  } else if(!fade && !weatherFired) {
    if(weatherMode == "now") {
      document.getElementById("weather").innerHTML = temperature + "° " + condition;
      if(ShowWeatherIcon && ShowWeather) {
        document.getElementById("weathericon").innerHTML = "<img src=icons/" + conditionCode + ".png height='" + WeatherIconSize + "' />";
      }
    } else if(weatherMode == "highlow") {
      document.getElementById("weather").innerHTML = high + "° / " + low + "°";
      if(ShowWeatherIcon && ShowWeather) {
        document.getElementById("weathericon").innerHTML = "<img src=icons/" + conditionCode + ".png height='" + WeatherIconSize + "' />";
      }
    } else if(weatherMode == "sunsetrise") {
      document.getElementById("weather").innerHTML = sunsetrise;
      if(ShowWeatherIcon && ShowWeather) {
        document.getElementById("weathericon").innerHTML = "<img src=icons/" + sunsetriseicon + ".png height='" + WeatherIconSize + "' />";
      }
    } else if(weatherMode == "rainchance") {
      document.getElementById("weather").innerHTML = rainchance + "%";
      if(ShowWeatherIcon && ShowWeather) {
        document.getElementById("weathericon").innerHTML = "<img src=icons/11.png height='" + WeatherIconSize + "' />";
      }
    } else if(weatherMode == "humpress") {
      document.getElementById("weather").innerHTML = "RH: " + humidity + "%&nbsp;&nbsp;" + pressure + "hPa";
      if(ShowWeatherIcon && ShowWeather) {
        document.getElementById("weathericon").innerHTML = "<img src=icons/" + conditionCode + ".png height='" + WeatherIconSize + "' />";
      }
    } else if(weatherMode == "wind") {
      document.getElementById("weather").innerHTML = windspeed + "km/h " + getCardinal(winddirection);
      if(ShowWeatherIcon && ShowWeather) {
        document.getElementById("weathericon").innerHTML = "<img src=icons/23.png height='" + WeatherIconSize + "' />";
      }
    } else if(weatherMode == "address") {
      document.getElementById("weather").innerHTML = temperature + "° " + city;
      if(ShowWeatherIcon && ShowWeather) {
        document.getElementById("weathericon").innerHTML = "<img src=icons/" + conditionCode + ".png height='" + WeatherIconSize + "' />";
      }
    }
  }
}

function getCardinal(deg){
  if (deg>11.25 && deg<33.75){
    return "NNE";
  }else if (deg>33.75 && deg<56.25){
    return "ENE";
  }else if (deg>56.25 && deg<78.75){
    return "E";
  }else if (deg>78.75 && deg<101.25){
    return "ESE";
  }else if (deg>101.25 && deg<123.75){
    return "ESE";
  }else if (deg>123.75 && deg<146.25){
    return "SE";
  }else if (deg>146.25 && deg<168.75){
    return "SSE";
  }else if (deg>168.75 && deg<191.25){
    return "S";
  }else if (deg>191.25 && deg<213.75){
    return "SSW";
  }else if (deg>213.75 && deg<236.25){
    return "SW";
  }else if (deg>236.25 && deg<258.75){
    return "WSW";
  }else if (deg>258.75 && deg<281.25){
    return "W";
  }else if (deg>281.25 && deg<303.75){
    return "WNW";
  }else if (deg>303.75 && deg<326.25){
    return "NW";
  }else if (deg>326.25 && deg<348.75){
    return "NNW";
  }else{
    return "N"; 
  }
}