var GlobalSettings = "";
var Mode = "centyfish"; //Choose between "leftyfish", "centyfish" and "righyfish"!

//Weather Settings:
var WeatherSettings = "";
var ShowWeather = true;
var ShowWeatherIcon = true;
var WeatherIconSize = "25px";
var WeatherTextColorAuto = true; //Auto select text-color based on your wallpaper. Overrides color setting
var WeatherTextColorAutoTheme = "Vibrant"; //Select  "Vibrant", "Muted", "DarkVibrant" or "DarkMuted"
var WeatherTextColor = "lightgrey"; //Hex-code or HTMl color name
var WeatherTextShadowBlur = "0px"; //0px equals off
var WeatherTextShadowColor = "#FFFFFF"; //Hex-code or HTMl color name
var WeatherFontSize = "18px";
var WeatherFontWeight = "650"; //Lightest: 100, Normal: 400, Bold: 700, Boldest: 900

var TimeSettings = "";
var ShowTime = true;
var TimeFormat = "24h"; //24h or 12h
var TimeShowAmPm = false; //Show am/pm if 12h is enabled
var TimeTextColorAuto = true; //Auto select text-color based on your wallpaper. Overrides color setting
var TimeTextColorAutoTheme = "DarkMuted"; //Select  "Vibrant", "Muted", "DarkVibrant" or "DarkMuted"
var TimeTextColor = "white"; //Hex-code or HTMl color name
var TimeTextShadowBlur = "0px"; //0px equals off
var TimeTextShadowColor = "#FFFFFF"; //Hex-code or HTMl color name
var TimeFontSize = "60px";
var TimeFontWeight = "500"; //Lightest: 100, Normal: 400, Bold: 700, Boldest: 900

var DateSettings = "";
var ShowDate = true;
var DateTextColorAuto = true; //Auto select text-color based on your wallpaper. Overrides color setting
var DateTextColorAutoTheme = "Vibrant"; //Select  "Vibrant", "Muted", "DarkVibrant" or "DarkMuted"
var DateTextColor = "lightgrey"; //Hex-code or HTMl color name
var DateTextShadowBlur = "0px"; //0px equals off
var DateTextShadowColor = "#FFFFFF"; //Hex-code or HTMl color name
var DateFontSize = "60px";
var DateFontWeight = "500"; //Lightest: 100, Normal: 400, Bold: 700, Boldest: 900
