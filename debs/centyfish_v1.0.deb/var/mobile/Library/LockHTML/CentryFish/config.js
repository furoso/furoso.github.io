var ShowWeather = true;
var ShowWeatherIcon = false; // Only showing cloudy/sunny atm
var WeatherIconColor = "white";
var WeatherTextColor = "lightgrey";
var WeatherFontSize = "18px";
var WeatherFontWeight = "650";

var ShowTime = true;
var TimeTextColor = "white";
var TimeFontSize = "60px";
var TimeFontWeight = "500";

var ShowDate = true;
var DateTextColor = "lightgrey";
var DateFontSize = "60px";
var DateFontWeight = "500";