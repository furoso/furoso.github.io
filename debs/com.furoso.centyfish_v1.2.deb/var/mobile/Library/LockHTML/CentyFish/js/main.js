function mainUpdate(type){
  if(type == "weather"){
    document.getElementById("weather").innerHTML = weather.temperature + "° " + weather.condition;
    if(ShowWeatherIcon && ShowWeather) {
      document.getElementById("weathericon").innerHTML = "<img src=icons/" + weather.conditionCode + ".png height='" + WeatherIconSize + "' />";
    }
    updateTimeDate();
  }
}

function init() {
  if(Mode == "leftyfish") {
    document.body.style.textAlign = "left";
  } else if(Mode == "centyfish") {
    document.body.style.textAlign = "center";
  } else {
    document.body.style.textAlign = "right";
  }


  var icon = "26";
  document.getElementById("weathericon").innerHTML = "<img src=icons/" + icon + ".png height='" + WeatherIconSize + "' />";

  updateTimeDate();
  setInterval("updateTimeDate();", 1000);

  if(!ShowWeatherIcon) {
    document.getElementById("weathericon").innerHTML = "";
    document.getElementById("weathericon").style.right = "0";
    document.getElementById("weathericon").style.width = "0";
  }

  if(ShowWeather) {
    document.getElementById("weather").style.color = WeatherTextColor;
    document.getElementById("weather").style.fontSize = WeatherFontSize;
    document.getElementById("weather").style.fontWeight = WeatherFontWeight;
  } else {
    document.getElementById("weathercontainer").style.visibility = "hidden";
    ShowWeatherIcon = false;
  }

  if(ShowTime) {
    document.getElementById("time").style.color = TimeTextColor;
    document.getElementById("time").style.fontSize = TimeFontSize;
    document.getElementById("time").style.fontWeight = TimeFontWeight;
  } else {
    document.getElementById("time").style.visibility = "hidden";
  }

  if(ShowDate) {
    document.getElementById("date").style.color = DateTextColor;
    document.getElementById("date").style.fontSize = DateFontSize;
    document.getElementById("date").style.fontWeight = DateFontWeight;
  } else {
    document.getElementById("date").style.visibility = "hidden";
  }
}

function updateTimeDate() {
  let now = new Date();
  if(now.getMinutes() < 10) {
    var minutes = "0" + now.getMinutes();
  } else {
    var minutes = now.getMinutes();
  }
  if(TimeFormat == "12h") {
    var ampm = now.getHours() >= 12 ? 'pm' : 'am';
    var hours = now.getHours() % 12;
    var hours = hours ? hours : 12; // the hour '0' should be '12'
    if(TimeShowAmPm) {
      var time = hours + ":" + minutes + " " + ampm;
    } else {
      var time = hours + ":" + minutes;
    }
  } else {
    var hours = now.getHours();
    var time = hours + ":" + minutes;
  }
  var days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  var date = days[now.getDay()] + " " + String(now.getDate()).padStart(2, '0');
  document.getElementById("time").innerHTML = time;
  document.getElementById("date").innerHTML = date;
}

updateTimeDate();