var ShowWeather = true;
var ShowWeatherIcon = false; //Only showing cloudy/sunny atm
var WeatherIconColor = "white"; //Hex-code or HTMl color name
var WeatherTextColor = "lightgrey"; //Hex-code or HTMl color name
var WeatherFontSize = "18px";
var WeatherFontWeight = "650"; //Lightest: 100, Normal: 400, Bold: 700, Boldest: 900

var ShowTime = true;
var TimeFormat = "24h"; //24h or 12h
var TimeShowAmPm = false; //Show am/pm if 12h is enabled
var TimeTextColor = "white"; //Hex-code or HTMl color name
var TimeFontSize = "60px";
var TimeFontWeight = "500"; //Lightest: 100, Normal: 400, Bold: 700, Boldest: 900

var ShowDate = true;
var DateTextColor = "lightgrey"; //Hex-code or HTMl color name
var DateFontSize = "60px";
var DateFontWeight = "500"; //Lightest: 100, Normal: 400, Bold: 700, Boldest: 900