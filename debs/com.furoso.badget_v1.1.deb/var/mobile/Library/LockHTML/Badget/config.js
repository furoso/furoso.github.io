var BackgroundColor = "#4c4c4c"; // Background-color in hex or HTML color names
var TextColor = "#f0efef"; // Text-color in hex or HTML color names
var ShowSymbol = true; // Display % after the percentage

var Charging = true; // Change color while charging
var ChargingColor = "lightseagreen";

var FirstLimit = true;
var FirstLimitPercentage = "20"; // Set the percentage to change the color for the first time
var FirstLimitColor = "darkorange"; // Set the color to be changed to

var SecondLimit = true;
var SecondLimitPercentage = "10"; // Set the percentage to change the color for the second time
var SecondLimitColor = "crimson"; // Set the color to be changed to