function mainUpdate(type){
  if(type == "battery"){
    if(ShowSymbol = true) {
      document.getElementById("percentage").innerHTML = batteryPercent + " %";
    } else {
      document.getElementById("percentage").innerHTML = batteryPercent;
    }
    

    if(batteryPercent <= FirstLimitPercentage && batteryPercent > SecondLimitPercentage && batteryCharging != true && FirstLimit) {
      document.getElementById("percentage").style.backgroundColor = FirstLimitColor;
    } else if(batteryPercent <= SecondLimitPercentage && batteryCharging != true && SecondLimit) {  
      document.getElementById("percentage").style.backgroundColor = SecondLimitColor;
    } else if(batteryCharging && Charging) {  
      document.getElementById("percentage").style.backgroundColor = ChargingColor;
    } else if(SecondLimitPercentage != true && batteryPercent <= FirstLimitPercentage && batteryCharging != true && FirstLimit) {
      document.getElementById("percentage").style.backgroundColor = FirstLimitColor;
    } else {
      document.getElementById("percentage").style.backgroundColor = BackgroundColor;
    }
  } 
  document.getElementById("percentage").style.color = TextColor;
}
