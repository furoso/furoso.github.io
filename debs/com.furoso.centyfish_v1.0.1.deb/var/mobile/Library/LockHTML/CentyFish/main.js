function mainUpdate(type){
  if(type == "weather"){
    document.getElementById("weather").innerHTML = weather.temperature + "° " + weather.condition;
    var conditionCode = weather.conditionCode;
  } 
  var conditionCode = 0;
  var conditions = [
    "wb_cloudy", /* tornado */
    "wb_cloudy", /* tropical storm */
    "wb_cloudy", /* hurricane */
    "wb_cloudy", /* severe thunderstorms */
    "wb_cloudy", /* thunderstorms */
    "wb_cloudy", /* mixed rain and snow */
    "wb_cloudy", /* mixed rain and sleet */
    "wb_cloudy", /* mixed snow and sleet */
    "wb_cloudy", /* freezing drizzle */
    "wb_cloudy", /* drizzle */
    "wb_cloudy", /* freezing rain */
    "wb_cloudy", /* showers */
    "wb_cloudy", /* showers */
    "wb_cloudy", /* snow flurries */
    "wb_cloudy", /* light snow showers */
    "wb_cloudy", /* blowing snow */
    "wb_cloudy", /* snow */
    "wb_cloudy", /* hail */
    "wb_cloudy", /* sleet */
    "wb_cloudy", /* dust */
    "wb_cloudy", /* foggy */
    "wb_cloudy", /* haze */
    "wb_cloudy", /* smoky */
    "wb_cloudy", /* blustery */
    "wb_cloudy", /* windy */
    "wb_cloudy", /* cold */
    "wb_cloudy", /* cloudy */
    "wb_cloudy", /* mostly cloudy (night) */
    "wb_cloudy", /* mostly cloudy (day) */
    "wb_cloudy", /* partly cloudy (night) */
    "wb_cloudy", /* partly cloudy (day) */
    "wb_sunny", /* clear (night) */
    "wb_sunny", /* sunny */
    "wb_cloudy", /* fair (night) */
    "wb_cloudy", /* fair (day) */
    "wb_cloudy", /* mixed rain and hail */
    "wb_cloudy", /* hot */
    "wb_cloudy", /* isolated thunderstorms */
    "wb_cloudy", /* scattered thunderstorms */
    "wb_cloudy", /* scattered thunderstorms */
    "wb_cloudy", /* scattered showers */
    "wb_cloudy", /* heavy snow */
    "wb_cloudy", /* scattered snow showers */
    "wb_cloudy", /* heavy snow */
    "wb_sunny", /* partly cloudy */
    "wb_cloudy", /* thundershowers */
    "wb_cloudy", /* snow showers */
    "wb_cloudy", /* isolated thundershowers */
  ];
  if(ShowWeatherIcon && ShowWeather) {
    document.getElementById("weathericon").innerHTML = conditions[conditionCode];
  }
}

function init() {
  let now = new Date();
  if(test < now.getMinutes()) {
    var minutes = "0" + now.getMinutes();
  } else {
    var minutes = now.getMinutes();
  }
  let time = now.getHours() + ":" + minutes;
  var days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  var date = days[now.getDay()] + " " + String(now.getDate()).padStart(2, '0');
  document.getElementById("time").innerHTML = time;
  document.getElementById("date").innerHTML = date;
  if(!ShowWeatherIcon) {
    document.getElementById("weathericon").innerHTML = "";
    document.getElementById("weathericon").style.right = "0";
    document.getElementById("weathericon").style.width = "0";
  }

  if(ShowWeather) {
    document.getElementById("weather").style.color = WeatherTextColor;
    document.getElementById("weathericon").style.color = WeatherIconColor;
    document.getElementById("weather").style.fontSize = WeatherFontSize;
    document.getElementById("weather").style.fontWeight = WeatherFontWeight;
  } else {
    document.getElementById("weathercontainer").style.visibility = "hidden";
    ShowWeatherIcon = false;
  }

  if(ShowTime) {
    document.getElementById("time").style.color = TimeTextColor;
    document.getElementById("time").style.fontSize = TimeFontSize;
    document.getElementById("time").style.fontWeight = TimeFontWeight;
  } else {
    document.getElementById("time").style.visibility = "hidden";
  }

  if(ShowDate) {
    document.getElementById("date").style.color = DateTextColor;
    document.getElementById("date").style.fontSize = DateFontSize;
    document.getElementById("date").style.fontWeight = DateFontWeight;
  } else {
    document.getElementById("date").style.visibility = "hidden";
  }
}